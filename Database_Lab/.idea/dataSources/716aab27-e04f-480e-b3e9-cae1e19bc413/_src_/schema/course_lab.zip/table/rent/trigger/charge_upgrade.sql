CREATE TRIGGER charge_upgrade
BEFORE INSERT ON rent
FOR EACH ROW
  BEGIN
    SET NEW.charge = if(minute(NEW.end_time - NEW.start_time) <= 30, 1,
                        if(minute(NEW.end_time - NEW.start_time) <= 60, 2,
                           if(minute(NEW.end_time - NEW.start_time) <= 90, 3, 4)));
    SELECT u.money
    INTO @mo
    FROM user u
    WHERE u.uid = NEW.uid;

    IF @mo < 0
    THEN SET NEW.uid = -1, NEW.bid = -1;
    ELSE UPDATE user u
    SET u.money = u.money - NEW.charge
    WHERE u.uid = NEW.uid;
    END IF;
  END;
